package com.submission.storyapp.data.local.entity

